## UI por linea de comando
from adaptacion_datos_0_8 import *
from reducir_ruido_0_8 import *
from corrector_de_formato import *

datos = ""
file_name = ""

def ask_file_name():
	file_name = str( input("ingrese nombre del archivo en crudo que desea procesar (debe tener extensión CSV:" ) )

	print("file_name 1 = " + file_name)

	return file_name

def ejec_correction_de_formato(input_file_name):
	## ejecuta script que se encarga de eliminar lineas erroneas

	len_line = 4																	## cantidad de datos separados por coma en cada linea
	corrected_file_name = input_file_name.replace(".csv", "_CORRECTED.csv")
	eliminar_errores(input_file_name, corrected_file_name, len_line)

	return(corrected_file_name)


## procesamiento de datos (reducción de ruido y otros algoritmos)
def reducir_ruido():
	##	INPUT	

	##	OUTPUT	

	print ("Ingresando a reducir_ruido()")
	auto_ejectucion_integrada()


## observación, configuración de parametros
def ejec_adaptacion_datos(input_file_name):
	##	INPUT	lee una lista de datos crudos compuesto por una fecha en timestramp, y dos valores de bateria y signal
	##	(float) Timestramp, (float) Signal, (float) Battery, (float) Variation
	print("ingresando a ejec_adaptacion_datos()")
	media_10000_name = adaptar_datos(input_file_name)
	print(str(datos[:100]) + "\nlisto...")

	##	OUTPUT	retorna una media por cada 10K datos
	##	(Date) Date, (int) Signal, (int) Battery, (int) Variation
	return media_10000_name





## visualización de grafico de FFT

	##	INPUT	

	##	OUTPUT	

def ejecutable():


	file_name = ask_file_name()

	file_name = ejec_correction_de_formato(file_name)		## reemplaza el nombre por el del archivo corregido

	auto_ejectucion_integrada(file_name)


	media_10000_name = ejec_adaptacion_datos(file_name)


ejecutable()






